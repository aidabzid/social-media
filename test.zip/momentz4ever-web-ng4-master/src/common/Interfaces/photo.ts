export interface Photo {
    photoId: string,
    likeCount: string,
    comment: string,
    title:string,
    description:string,
    imageUrl:string,
    createdDate:string
}