export interface Album {
    albumId: string,
    title:string,
    description:string,
    imageUrl:string,
    createdDate:string,
    lastViewedOn:string
}